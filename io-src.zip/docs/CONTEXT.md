# IO — portable project context

Date: 2025-10-23
Branch: main

This document captures the working context so the assistant on another machine (e.g., Linux) can load the essentials without re-deriving history. It summarizes architecture, recent changes, build/test steps, style, and next actions.

## Overview

- Language/Tooling: C++17, CMake, GoogleTest, CPack
- Library: cross-platform event loop + networking with multiple backends
  - Linux: epoll, io_uring (optional, via liburing)
  - macOS/BSD: kqueue
  - Windows: IOCP
  - Solaris/Illumos: event ports, devpoll
- Features
  - async accept/connect/read/write
  - post(uint32_t) user events
  - per-socket read timeouts (close on idle)
  - pause_read / resume_read
  - logging hooks
- Structure
  - `include/io/*.hpp`, `src/net_*.cpp`, `examples/`, `tests/`
  - CMakePresets for debug/release/asan/tsan/ubsan

## Recent changes (macOS validated)

- Formatting: unified via `.clang-format` (tabs, K&R attach braces, width 120). Repo-wide autoformat applied.
- Tests migrated to `io::socket_t` and `io::kInvalidSocket` for portability (Windows-friendly).
- io_uring hardening: guarded SQE submissions (ring mutex), safer accept path, avoid pre-connect recv; extra diagnostics.
- epoll: tolerate EPOLL_CTL_ADD EEXIST by falling back to MOD; improve connect success path.
- CMake: set global CTest timeout to prevent hangs; policy updates; liburing optional.
- All tests pass on macOS under Debug/ASan/TSan/UBSan. Highload TSan test repeated 100× — PASS.

## Build & test (Linux)

Dependencies (Debian/Ubuntu example):

```bash
sudo apt update
sudo apt install -y build-essential cmake pkg-config git \
  clang clang-format llvm \
  liburing-dev \
  libasan5 libubsan1 libtsan0 || true
```

Configure and build:

```bash
# Debug
cmake --preset debug
cmake --build --preset debug -j$(nproc)

# Sanitizers
cmake --preset asan && cmake --build --preset asan -j$(nproc)
cmake --preset tsan && cmake --build --preset tsan -j$(nproc)
cmake --preset ubsan && cmake --build --preset ubsan -j$(nproc)
```

Run tests:

```bash
ctest --test-dir ./build/debug -j4 --output-on-failure
ctest --test-dir ./build/asan  -j4 --output-on-failure
ctest --test-dir ./build/tsan  -j4 --output-on-failure
ctest --test-dir ./build/ubsan -j4 --output-on-failure

# Stress
ctest --test-dir ./build/tsan -R NetHighload.ManyClientsEchoNoBlock -j1 --repeat until-fail:100 --output-on-failure
```

io_uring notes:

- Requires modern kernel (5.x+). If liburing or kernel features are unavailable, build falls back to epoll (option-controlled).
- If hangs occur, capture `ctest` output and `dmesg` snippets for diagnostics.

## Style

- `.clang-format` (excerpt):
  - `UseTab: Always`, `IndentWidth: 4`, `TabWidth: 4`, `BreakBeforeBraces: Attach`, `ColumnLimit: 120`, `SortIncludes: true`, `AllowShortFunctionsOnASingleLine: Empty`
- `.editorconfig`: spaces=2 are set editor-wide, but clang-format governs C/C++ code (tabs). Editors should defer to clang-format.

## Key files

- API: `include/io/net.hpp`, `include/io/socket_t.hpp`, `include/io/io.hpp`
- Backends: `src/net_epoll.cpp`, `src/net_iouring.cpp`, `src/net_kqueue.cpp`, `src/net_iocp.cpp`, `src/net_eventports.cpp`, `src/net_devpoll.cpp`
- Factory: `src/net_factory.cpp`
- Tests: `tests/*.cpp` including highload, integration, timeouts, pause/resume
- Examples: `examples/client.cpp`, `examples/server.cpp`

## Next steps (Linux focus)

1) Validate io_uring on Linux with current hardening.
2) If issues: collect logs and add targeted fixes (SQE pressure, timeout bookkeeping, connect race edges).
3) Optionally add a CI style check (clang-format) and release packaging job.
4) Windows cross-check (IOCP) once Linux is stable.

## How to share results back

Share:
- `ctest` outputs (`--output-on-failure`), failing test names
- `build/*/CMakeFiles/CMakeError.log` if configuration fails
- `dmesg` excerpts for io_uring-related errors

This CONTEXT.md is designed to be read by the assistant to quickly regain full context on another machine.

## Solaris over SSH (remote debug)

Scripts in `scripts/solaris/` help sync/build/test on a remote Solaris host:

- Copy `scripts/solaris/.env.example` to `.env` and adjust:
  - `SOLARIS_SSH=user@host`, `SOLARIS_SSH_PORT=222` (if non-default), optional `SOLARIS_SSH_OPTS` like `-o StrictHostKeyChecking=no`
  - `SOLARIS_DIR=/opt/work/io`, `SOLARIS_BUILD=build/sol`
  - `SOLARIS_EVENTPORTS=ON` to use Event Ports (default), OFF to fallback to /dev/poll

Workflow from project root:

```bash
# 1) push sources
scripts/solaris/solaris_sync.sh

# 2) configure (Debug, tests/examples ON, Event Ports ON)
scripts/solaris/solaris_configure.sh

# 3) build
scripts/solaris/solaris_build.sh

# 4) run tests
scripts/solaris/solaris_test.sh

# 5) run examples (server+client)
scripts/solaris/solaris_run_examples.sh

# 6) debug a binary remotely with gdb
scripts/solaris/solaris_gdb.sh io_tests
```

Notes
- Ensure `cmake`/`ctest`/`gdb` are installed on Solaris. If needed, set absolute paths in `.env`.
- Event Ports backend is enabled with `-DIO_WITH_EVENTPORTS=ON` (default). `/dev/poll` fallback with `OFF`.
- If tests fail, grab failing output and share. For event ports timing issues, also check system logs.

## Solaris timing: Event Ports and /dev/poll (unified, threadless)

Context
- We no longer rely on kernel timers with SIGEV_PORT nor on helper timer threads. Both Solaris backends implement idle read timeouts by converting the nearest per-socket deadline into the blocking wait timeout (`port_getn` for Event Ports, `DP_POLL` for /dev/poll).

Implementation
- Data structures: a map of socket -> {timeout_ms, deadline, active} managed in the main thread.
- Each successful read re-arms the deadline. Paused sockets don't expire; on resume, deadlines continue.
- `loop_once(now)` computes `next_timeout_ms(now)` as the minimum positive (remaining) deadline across active sockets and passes it to the wait primitive.
- After handling events, `close_expired(now)` closes any sockets whose deadlines have passed and invokes `on_close`.
- User events: Event Ports use `port_send(PORT_SOURCE_USER)`; /dev/poll uses an internal user pipe.

port_getn and ETIME
- `port_getn` may return ETIME when the timeout elapses without events; treat it like "no events" (similar to EINTR handling). This is expected and not an error.

Behavior and guarantees
- Per-socket idle read timeouts behave consistently across backends.
- Pause/Resume semantics match other platforms.
- User events are FIFO and don't starve I/O events.

Validation status (Solaris)
- Full suite passing (both backends).
- Highload stress: sequential 300 iterations PASS (remote scripts in `scripts/solaris/`).

Related scripts
- `scripts/solaris/solaris_sync.sh`, `solaris_configure.sh`, `solaris_build.sh`, `solaris_test.sh` — end-to-end loop for remote Solaris.
